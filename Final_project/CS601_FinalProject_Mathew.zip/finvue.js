// src/main.js
import App from './component/appvue.js';

new Vue({
  render: h => h(App),
}).$mount(`#app`);